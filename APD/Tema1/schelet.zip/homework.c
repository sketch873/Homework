#include "homework.h"

int num_threads;
int resize_factor;

void readInput(const char * fileName, image *img) {

}

void writeData(const char * fileName, image *img) {

}

void resize(image *in, image * out) { 

}