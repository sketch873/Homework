class Par implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Null implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Acol implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Not implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class If implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {
	}
	
}

class Bl implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class And implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Wh implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Gt implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Equal implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Sum implements Expression {

	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}

	@Override
	public void test() {		
	}
	
}

class Div implements Expression {
	int line;
	
	public Div(int line) {
		super();
		this.line = line;
	}
	@Override
	public String show() {
		return null;
	}

	@Override
	public String interpret() {
		return null;
	}
	@Override
	public void test() {		
	}
	
}