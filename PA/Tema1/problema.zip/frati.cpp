#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>

using namespace std;

typedef struct obj{
	int jocuri;
	int benzi;
} obiect;

ifstream in("frati.in");
ofstream out("frati.out");

bool comp1(obiect o1, obiect o2) {

	if(o1.jocuri + o1.benzi > o2.jocuri + o2.benzi)
		return true;
	if(o1.jocuri + o1.benzi < o2.jocuri + o2.benzi)
		return false;

	if(o1.jocuri > o2.jocuri)
		return true;
	else
		return false;

}

int main() {
	vector<obiect> x(1000);
	int n;
	int sam = 0, jon = 0;

	in>>n;
	for(int i = 0; i < n; i++)
		in>>x[i].jocuri>>x[i].benzi;


	sort(x.begin(), x.begin() + n, comp1);

	for(int i = 0; i < n; i++) {
		for(int j = i + 1; j < n; j++) {
			if(x[i].jocuri + x[i].benzi != x[j].jocuri + x[j].benzi)
				break;
			if(i%2 == 0 && x[i].jocuri < x[j].jocuri) {
				obiect aux = x[i];
				x[i] = x[j];
				x[j] = aux;
			} else if(i%2 == 1 && x[i].benzi < x[j].benzi) {
				obiect aux = x[i];
				x[i] = x[j];
				x[j] = aux;
			}
		}
	}

	for(int i = 0; i < n; i++) {
		if(i%2 == 0)
			jon += x[i].jocuri;
		else
			sam += x[i].benzi;
	}

/*
	for(int i = 0; i < n; i++)
		cout<<x[i].jocuri<<" "<<x[i].benzi<<endl;
*/
	out<<jon<<" "<<sam;



	return 0;
}
